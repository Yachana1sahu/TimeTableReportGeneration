// src/routes/TutorialRoutes.js
import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all tutorial details
router.get("/", (req, res) => {
    const query = `
        SELECT t.TutorialID, t.SubjectID, s.SubjectCode, t.HoursPerWeek
        FROM TutorialDetails t
        JOIN SubjectDetails s ON t.SubjectID = s.SubjectID;
    `;
    db.query(query, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// Get tutorial details by ID
router.get('/:id', (req, res) => {
    const query = 'SELECT * FROM TutorialDetails WHERE TutorialID = ?';
    db.query(query, [req.params.id], (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data[0]);
    });
});

// Create a new tutorial detail
router.post("/", (req, res) => {
    const query = `
        INSERT INTO TutorialDetails (SubjectID, HoursPerWeek)
        VALUES (?, ?)
    `;
    const values = [
        req.body.SubjectID,
        req.body.HoursPerWeek,
    ];
    db.query(query, values, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json("Tutorial detail created successfully");
    });
});

// Update a tutorial detail by ID
router.put("/:id", (req, res) => {
    const query = `
        UPDATE TutorialDetails
        SET SubjectID = ?, HoursPerWeek = ?
        WHERE TutorialID = ?
    `;
    const values = [
        req.body.SubjectID,
        req.body.HoursPerWeek,
        req.params.id,
    ];
    db.query(query, values, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json("Tutorial detail updated successfully");
    });
});

// Delete a tutorial detail by ID
router.delete("/:id", (req, res) => {
    const query = 'DELETE FROM TutorialDetails WHERE TutorialID = ?';
    db.query(query, [req.params.id], (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json("Tutorial detail deleted successfully");
    });
});

export { router as TutorialRoutes };
