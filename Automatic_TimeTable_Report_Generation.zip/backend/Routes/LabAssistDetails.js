
import express from 'express';
import db from '../db.js';
const router = express.Router();


const generateNameDetails = (FirstName, MiddleName, LastName) => {
    const FullName = [FirstName, MiddleName, LastName].filter(name => name).join(' ');
    let shortName = FirstName[0].toUpperCase();
    if (MiddleName) shortName += MiddleName[0].toUpperCase();
    return { FullName, ShortName: shortName };
};



router.get('/', (req, res) => {
    const q = 'SELECT AssistantID, FirstName, MiddleName, LastName, CONCAT(FirstName, " ", MiddleName, " ", LastName) AS FullName, CONCAT(UPPER(SUBSTRING(FirstName, 1, 1)), IF(MiddleName != "", UPPER(SUBSTRING(MiddleName, 1, 1)), ""), UPPER(SUBSTRING(LastName, 1, 1))) AS ShortName FROM Lab_Assistant';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});


router.get('/:id', (req, res) => {
    const q = 'SELECT AssistantID, FirstName, MiddleName, LastName, CONCAT(FirstName, " ", MiddleName, " ", LastName) AS FullName, CONCAT(UPPER(SUBSTRING(FirstName, 1, 1)), IF(MiddleName != "", UPPER(SUBSTRING(MiddleName, 1, 1)), ""), UPPER(SUBSTRING(LastName, 1, 1))) AS ShortName FROM Lab_Assistant WHERE AssistantID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});


router.post('/', (req, res) => {
    const { FirstName, MiddleName, LastName } = req.body;

    if (!FirstName || !LastName) {
        return res.status(400).json({ message: 'FirstName and LastName are required.' });
    }

    // Generate FullName and ShortName
    const { FullName, ShortName } = generateNameDetails(FirstName, MiddleName, LastName);

    const q = 'INSERT INTO Lab_Assistant (FirstName, MiddleName, LastName, FullName, ShortName) VALUES (?, ?, ?, ?, ?)';
    const values = [FirstName, MiddleName, LastName, FullName, ShortName];

    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Lab Assistant added successfully');
    });
});

router.put('/:id', (req, res) => {
    const { FirstName, MiddleName, LastName } = req.body;
    const { FullName, ShortName } = generateNameDetails(FirstName, MiddleName, LastName);

    const q = 'UPDATE Lab_Assistant SET FirstName = ?, MiddleName = ?, LastName = ?, FullName = ?, ShortName = ? WHERE AssistantID = ?';
    const values = [FirstName, MiddleName, LastName, FullName, ShortName, req.params.id];

    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Lab Assistant updated successfully');
    });
});

router.delete('/:id', (req, res) => {
    const q = 'DELETE FROM Lab_Assistant WHERE AssistantID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Lab Assistant deleted successfully');
    });
});





export { router as Lab_AssistantRoutes };
