import express from "express";
import db from "../db.js";


const router = express.Router();

router.get("/", (req, res) => {
    const q = "SELECT * FROM classroom ";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    })
});

router.post("/", (req, res) => {
    const q = "INSERT INTO classroom (ClassroomName,Capacity) VALUES (? , ?)";
    const values = [req.body.ClassroomName,
    req.body.Capacity
    ];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Classroom created successfully");
    })
})



router.delete("/:id", (req, res) => {
    const classroomID = req.params.id;
    const q = 'DELETE FROM classroom WHERE classroomID = ?';
    db.query(q, [classroomID], (err, data) => {
        if (err) return res.json(err);
        return res.json("classroom has been deleted successfully");
    })
})

router.put("/:id", (req, res) => {
    const classroomID = req.params.id;
    const q = "UPDATE classroom SET ClassroomName = ?, Capacity = ? WHERE classroomID = ? ";
    const values = [req.body.ClassroomName, req.body.Capacity];
    db.query(q, [...values, classroomID], (err, data) => {
        if (err) return res.json(err);
        return res.json("Classroom has been updated successfully");
    });
})





export { router as ClassRoutes }