import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all sections
router.get("/", (req, res) => {
    const q = "SELECT * FROM Section";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Add a new section
router.post("/", (req, res) => {
    const q = "INSERT INTO Section (`SectionName`) VALUES(?)";
    const values = [req.body.SectionName];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Section has been created successfully");
    });
});

// Delete a section by ID
router.delete("/:id", (req, res) => {
    const sectionId = req.params.id;
    const q = "DELETE FROM Section WHERE SectionID = ?";
    db.query(q, [sectionId], (err, data) => {
        if (err) return res.json(err);
        return res.json("Section has been deleted successfully");
    });
});

// Update a section by ID
router.put("/:id", (req, res) => {
    const sectionId = req.params.id;
    const q = "UPDATE Section SET SectionName = ? WHERE SectionID = ?";
    const values = [req.body.SectionName];
    db.query(q, [...values, sectionId], (err, data) => {
        if (err) return res.json(err);
        return res.json("Section has been updated successfully");
    });
});

export { router as SectionRoutes };
