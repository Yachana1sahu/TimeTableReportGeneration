

import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all YearSemester records with CourseName
router.get("/", (req, res) => {
    const q = `
        SELECT 
            ys.YearSemesterID,
            ys.Year,
            ys.Semester,
            c.CourseName
        FROM 
            YearSemester ys
        JOIN 
            Course c ON ys.CourseID = c.CourseID;
    `;
    db.query(q, (err, data) => {
        if (err) return res.status(500).json(err);
        return res.status(200).json(data);
    });
});

// Get a single YearSemester record by ID
router.get("/:id", (req, res) => {
    const { id } = req.params;
    const query = `
        SELECT 
            ys.YearSemesterID,
            ys.Year,
            ys.Semester,
            c.CourseName
        FROM 
            YearSemester ys
        JOIN 
            Course c ON ys.CourseID = c.CourseID
        WHERE 
            ys.YearSemesterID = ?
    `;
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.length === 0) return res.status(404).json({ message: "Record not found" });
        res.status(200).json(results[0]);
    });
});

// Create a new YearSemester record
router.post("/", (req, res) => {
    const { Year, Semester, CourseID } = req.body;
    const query = "INSERT INTO YearSemester (Year, Semester, CourseID) VALUES (?, ?, ?)";
    db.query(query, [Year, Semester, CourseID], (err, results) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ message: "YearSemester record created", id: results.insertId });
    });
});

// Update an existing YearSemester record by ID
router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { Year, Semester, CourseID } = req.body;
    const query = "UPDATE YearSemester SET Year = ?, Semester = ?, CourseID = ? WHERE YearSemesterID = ?";
    db.query(query, [Year, Semester, CourseID, id], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.affectedRows === 0) return res.status(404).json({ message: "Record not found" });
        res.status(200).json({ message: "YearSemester record updated" });
    });
});

// Delete a YearSemester record by ID
router.delete("/:id", (req, res) => {
    const { id } = req.params;
    const query = "DELETE FROM YearSemester WHERE YearSemesterID = ?";
    db.query(query, [id], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.affectedRows === 0) return res.status(404).json({ message: "Record not found" });
        res.status(200).json({ message: "YearSemester record deleted" });
    });
});

export { router as YearSemRoutes };
