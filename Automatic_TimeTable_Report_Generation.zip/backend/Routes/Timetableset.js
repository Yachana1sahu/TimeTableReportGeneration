
import express from "express";
import db from "../db.js";

const router = express.Router();

// Route to create a timetable entry
router.post("/", (req, res) => {
    const {
        YearSemesterID,
        TimeSlotID,
        DayOfWeekID,
        SubjectID,
        ClassroomID,
        LaboratoryID,
        SessionID,
        SectionID,
        FacultyIDs,
        LabAssistantIDs,
        PGStudentIDs,
        BatchIDs,
    } = req.body;

    console.log("Request Body:", req.body);

    const timetableQuery =
        'INSERT INTO Timetableset (YearSemesterID, TimeSlotID, DayOfWeekID, SubjectID, ClassroomID, LaboratoryID, SessionID, SectionID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';

    const timetableData = [
        YearSemesterID,
        TimeSlotID,
        DayOfWeekID,
        SubjectID,
        ClassroomID,
        LaboratoryID,
        SessionID,
        SectionID,
    ];

    db.query(timetableQuery, timetableData, (err, result) => {
        if (err) {
            console.error('Error inserting timetable: ', err);
            return res.status(500).send('Error inserting timetable');
        }

        const timetablesetID = result.insertId;
        console.log("a", result.insertId, timetableData);

        // Array to hold all insertion promises
        const insertionPromises = [];

        // Insert Faculty IDs
        if (FacultyIDs && FacultyIDs.length > 0) {
            console.log("faculties ID", FacultyIDs);
            const facultyValues = FacultyIDs.map((facultyID) => [timetablesetID, facultyID]);
            const facultyQuery = 'INSERT INTO TimetableFaculty (TimetablesetID, FacultyID) VALUES ?';
            insertionPromises.push(
                new Promise((resolve, reject) => {
                    db.query(facultyQuery, [facultyValues], (err) => {
                        if (err) {
                            console.error('Error inserting faculty: ', err);
                            return reject('Error inserting faculty');
                        }
                        resolve();
                    });
                })
            );
        }

        // Insert Lab Assistant IDs
        if (LabAssistantIDs && LabAssistantIDs.length > 0) {
            const labAssistantValues = LabAssistantIDs.map((assistantID) => [timetablesetID, assistantID]);
            const labAssistantQuery = 'INSERT INTO TimetableLabAssistant (TimetablesetID, LabAssistantID) VALUES ?';
            insertionPromises.push(
                new Promise((resolve, reject) => {
                    db.query(labAssistantQuery, [labAssistantValues], (err) => {
                        if (err) {
                            console.error('Error inserting lab assistants: ', err);
                            return reject('Error inserting lab assistants');
                        }
                        resolve();
                    });
                })
            );
        }

        // Insert PG Student IDs
        if (PGStudentIDs && PGStudentIDs.length > 0) {
            const pgStudentValues = PGStudentIDs.map((studentID) => [timetablesetID, studentID]);
            const pgStudentQuery = 'INSERT INTO TimetablePGStudent (TimetablesetID, PGStudentID) VALUES ?';
            insertionPromises.push(
                new Promise((resolve, reject) => {
                    db.query(pgStudentQuery, [pgStudentValues], (err) => {
                        if (err) {
                            console.error('Error inserting PG students: ', err);
                            return reject('Error inserting PG students');
                        }
                        resolve();
                    });
                })
            );
        }

        // Insert Batch IDs
        if (BatchIDs && BatchIDs.length > 0) {
            const batchValues = BatchIDs.map((batchID) => [timetablesetID, batchID]);
            const batchQuery = 'INSERT INTO TimetableBatch (TimetablesetID, BatchID) VALUES ?';
            insertionPromises.push(
                new Promise((resolve, reject) => {
                    db.query(batchQuery, [batchValues], (err) => {
                        if (err) {
                            console.error('Error inserting batches: ', err);
                            return reject('Error inserting batches');
                        }
                        resolve();
                    });
                })
            );
        }

        // Execute all insertion promises and send response once all are done


        Promise.all(insertionPromises)
            .then(() => {
                res.status(201).send({ message: 'Timetable created successfully!' });
            })
            .catch((error) => {
                console.error(error);
                res.status(500).send(error);
            });
    });
});

// Route to fetch all timetables with full information (including faculty, lab assistants, PG students, and batches)
router.get('/', (req, res) => {
    const query = `
        SELECT 
            t.TimetablesetID, t.YearSemesterID, t.TimeSlotID, t.DayOfWeekID, 
            t.SubjectID, t.ClassroomID, t.LaboratoryID, t.SessionID, t.SectionID,
            GROUP_CONCAT(DISTINCT f.FacultyID) AS FacultyIDs,
            GROUP_CONCAT(DISTINCT la.LabAssistantID) AS LabAssistantIDs,
            GROUP_CONCAT(DISTINCT p.PGStudentID) AS PGStudentIDs,
            GROUP_CONCAT(DISTINCT b.BatchID) AS BatchIDs
        FROM Timetableset t
        LEFT JOIN TimetableFaculty f ON t.TimetablesetID = f.TimetablesetID
        LEFT JOIN TimetableLabAssistant la ON t.TimetablesetID = la.TimetablesetID
        LEFT JOIN TimetablePGStudent p ON t.TimetablesetID = p.TimetablesetID
        LEFT JOIN TimetableBatch b ON t.TimetablesetID = b.TimetablesetID
        GROUP BY t.TimetablesetID
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching timetables with full data: ', err);
            return res.status(500).send('Error fetching timetables');
        }

        const formattedResults = results.map(timetable => ({
            TimetablesetID: timetable.TimetablesetID,
            YearSemesterID: timetable.YearSemesterID,
            TimeSlotID: timetable.TimeSlotID,
            DayOfWeekID: timetable.DayOfWeekID,
            SubjectID: timetable.SubjectID,
            ClassroomID: timetable.ClassroomID,
            LaboratoryID: timetable.LaboratoryID,
            SessionID: timetable.SessionID,
            SectionID: timetable.SectionID,
            FacultyIDs: timetable.FacultyIDs ? timetable.FacultyIDs.split(',') : [],
            LabAssistantIDs: timetable.LabAssistantIDs ? timetable.LabAssistantIDs.split(',') : [],
            PGStudentIDs: timetable.PGStudentIDs ? timetable.PGStudentIDs.split(',') : [],
            BatchIDs: timetable.BatchIDs ? timetable.BatchIDs.split(',') : [],
        }));

        res.status(200).json(formattedResults);
    });
});

// Route to fetch timetable by ID
router.get('/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM Timetableset WHERE TimetablesetID = ?';

    db.query(query, [id], (err, result) => {
        if (err) {
            console.error('Error fetching timetable by ID: ', err);
            return res.status(500).send('Error fetching timetable');
        }

        res.status(200).json(result);
    });
});

// Route to get Faculty IDs for a specific Timetable
router.get('/:id/faculty', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT FacultyID FROM TimetableFaculty WHERE TimetablesetID = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching faculty for timetable: ', err);
            return res.status(500).send('Error fetching faculty');
        }

        res.status(200).json(results);
    });
});

// Route to get Lab Assistant IDs for a specific Timetable
router.get('/:id/labassistant', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT LabAssistantID FROM TimetableLabAssistant WHERE TimetablesetID = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching lab assistants for timetable: ', err);
            return res.status(500).send('Error fetching lab assistants');
        }

        res.status(200).json(results);
    });
});

// Route to get PG Student IDs for a specific Timetable
router.get('/:id/pgstudents', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT PGStudentID FROM TimetablePGStudent WHERE TimetablesetID = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching PG students for timetable: ', err);
            return res.status(500).send('Error fetching PG students');
        }

        res.status(200).json(results);
    });
});

// Route to get Batch IDs for a specific Timetable
router.get('/:id/batches', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT BatchID FROM TimetableBatch WHERE TimetablesetID = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching batches for timetable: ', err);
            return res.status(500).send('Error fetching batches');
        }

        res.status(200).json(results);
    });
});


router.put("/:id", (req, res) => {
    const { id } = req.params; // TimetablesetID from URL params
    const {
        yearSemesterID,
        timeSlotID,
        dayOfWeekID,
        subjectID,
        classroomID,
        laboratoryID,
        sessionID,
        sectionID,
        facultyIDs,
        labAssistantIDs,
        pgStudentIDs,
        batchIDs,
    } = req.body;

    // Step 1: Delete all related data before updating
    const deleteQueries = [
        'DELETE FROM TimetableFaculty WHERE TimetablesetID = ?',
        'DELETE FROM TimetableLabAssistant WHERE TimetablesetID = ?',
        'DELETE FROM TimetablePGStudent WHERE TimetablesetID = ?',
        'DELETE FROM TimetableBatch WHERE TimetablesetID = ?',
    ];

    const deletionPromises = deleteQueries.map((query) => {
        return new Promise((resolve, reject) => {
            db.query(query, [id], (err) => {
                if (err) {
                    console.error(`Error deleting related records: ${err}`);
                    return reject('Error deleting related records');
                }
                resolve();
            });
        });
    });

    // Step 2: Update the timetable entry
    const timetableQuery = `
        UPDATE Timetableset
        SET YearSemesterID = ?, TimeSlotID = ?, DayOfWeekID = ?, SubjectID = ?, ClassroomID = ?, LaboratoryID = ?, SessionID = ?, SectionID = ?
        WHERE TimetablesetID = ?
    `;

    const timetableData = [
        yearSemesterID,
        timeSlotID,
        dayOfWeekID,
        subjectID,
        classroomID,
        laboratoryID,
        sessionID,
        sectionID,
        id,
    ];

    Promise.all(deletionPromises)
        .then(() => {
            return new Promise((resolve, reject) => {
                db.query(timetableQuery, timetableData, (err) => {
                    if (err) {
                        console.error('Error updating timetable: ', err);
                        return reject('Error updating timetable');
                    }
                    resolve();
                });
            });
        })
        .then(() => {
            const insertionPromises = [];

            // Function to insert related data
            const insertRelatedData = (table, data, query) => {
                if (data && data.length > 0) {
                    const values = data.map((item) => [id, item]);
                    insertionPromises.push(
                        new Promise((resolve, reject) => {
                            db.query(query, [values], (err) => {
                                if (err) {
                                    console.error(`Error inserting ${table}: `, err);
                                    return reject(`Error inserting ${table}`);
                                }
                                resolve();
                            });
                        })
                    );
                }
            };

            // Insert new related data
            insertRelatedData('faculty', facultyIDs, 'INSERT INTO TimetableFaculty (TimetablesetID, FacultyID) VALUES ?');
            insertRelatedData('lab assistants', labAssistantIDs, 'INSERT INTO TimetableLabAssistant (TimetablesetID, LabAssistantID) VALUES ?');
            insertRelatedData('PG students', pgStudentIDs, 'INSERT INTO TimetablePGStudent (TimetablesetID, PGStudentID) VALUES ?');
            insertRelatedData('batches', batchIDs, 'INSERT INTO TimetableBatch (TimetablesetID, BatchID) VALUES ?');

            return Promise.all(insertionPromises);
        })
        .then(() => {
            res.status(200).send({ message: 'Timetable and related data updated successfully!' });
        })
        .catch((error) => {
            console.error(error);
            res.status(500).send({ error });
        });
});




router.delete('/:id', (req, res) => {
    const { id } = req.params;

    // Queries to delete related records first
    const deleteQueries = [
        { query: 'DELETE FROM TimetableFaculty WHERE TimetablesetID = ?', table: 'TimetableFaculty' },
        { query: 'DELETE FROM TimetableLabAssistant WHERE TimetablesetID = ?', table: 'TimetableLabAssistant' },
        { query: 'DELETE FROM TimetablePGStudent WHERE TimetablesetID = ?', table: 'TimetablePGStudent' },
        { query: 'DELETE FROM TimetableBatch WHERE TimetablesetID = ?', table: 'TimetableBatch' },
        { query: 'DELETE FROM Timetableset WHERE TimetablesetID = ?', table: 'Timetableset' }
    ];

    // Function to execute delete queries sequentially
    const deleteData = async () => {
        try {
            // Sequentially delete records from each table
            for (const { query, table } of deleteQueries) {
                await new Promise((resolve, reject) => {
                    db.query(query, [id], (err) => {
                        if (err) {
                            console.error(`Error deleting from ${table}: ${err}`);  // Log specific table name
                            return reject(`Error deleting from ${table}`);
                        }
                        resolve();
                    });
                });
            }

            // If all deletions succeed, send success response

            res.status(200).send({ message: 'Timetable and related records deleted successfully!' });
        } catch (error) {
            // Catch any error and respond with a failure message
            console.error('Error during deletion process: ', error);
            res.status(500).send({ error: 'Error during deletion' });
        }
    };
    console.log(`Attempting to delete TimetablesetID: ${id}`);
    // Call the delete function
    deleteData();
});



export { router as TimetablesetRoutes };