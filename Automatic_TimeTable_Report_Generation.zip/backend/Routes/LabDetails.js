import express from "express";
import db from "../db.js";


const router = express.Router();

router.get("/", (req, res) => {
    const q = "SELECT * FROM Laboratory";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    })
})

router.post("/", (req, res) => {
    console.log(req.body);
    const q = "INSERT INTO Laboratory (LaboratoryName,Capacity) VALUES (? ,? )";
    const values = [req.body.LaboratoryName,
    req.body.Capacity
    ];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Laboratory created successfully");
    })
})











router.delete("/:id", (req, res) => {
    const LaboratoryID = req.params.id;
    const q = 'DELETE FROM Laboratory WHERE LaboratoryID  = ?';
    db.query(q, [LaboratoryID], (err, data) => {
        if (err) return res.json(err);
        return res.json("Laboratory has been deleted successfully");
    })
})

router.put("/:id", (req, res) => {
    const LaboratoryID = req.params.id;
    const q = "UPDATE Laboratory SET LaboratoryName = ?Capacity = ? WHERE LaboratoryID = ? ";
    const values = [req.body.LaboratoryName, req.body.Capacity];
    db.query(q, [...values, LaboratoryID], (err, data) => {
        if (err) return res.json(err);
        return res.json("Laboratory has been updated successfully");
    })
})









export { router as LabRoutes }