import express from "express";
import db from "../db.js"; // Adjust the path according to your project structure

const router = express.Router();

// Create a new TheoryDetail
router.post("/", (req, res) => {
    const { SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksTheoryExam, CWTheoryclass } = req.body;

    const q = `INSERT INTO TheoryDetails (SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksTheoryExam, CWTheoryclass)
               VALUES (?, ?, ?, ?, ?)`;

    const values = [SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksTheoryExam, CWTheoryclass];

    db.query(q, values, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "TheoryDetail created successfully" });
    });
});

// Read all TheoryDetails
router.get("/", (req, res) => {
    // const q = "SELECT * FROM TheoryDetails";
    const q = `
    SELECT t.TheoryID, t.SubjectID, s.SubjectCode, t.HoursPerWeek, t.MaxCreditMarks, t.MaxMarksTheoryExam, t.CWTheoryclass
    FROM TheoryDetails t
    JOIN SubjectDetails s ON t.SubjectID = s.SubjectID;
`;

    db.query(q, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(200).json(data);
    });
});

// Read a single TheoryDetail by ID
router.get("/:id", (req, res) => {
    const { id } = req.params;
    // const q = "SELECT * FROM TheoryDetails WHERE TheoryID = ?";

    const q = `
        SELECT t.TheoryID, t.SubjectID, s.SubjectCode, t.HoursPerWeek, t.MaxCreditMarks, t.MaxMarksTheoryExam, t.CWTheoryclass
        FROM TheoryDetails t
        JOIN SubjectDetails s ON t.SubjectID = s.SubjectID
        WHERE t.TheoryID = ?;
    `;


    db.query(q, [id], (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        if (data.length === 0) return res.status(404).json({ message: "TheoryDetail not found" });
        return res.status(200).json(data[0]);
    });
});

// Update a TheoryDetail by ID
router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksTheoryExam, CWTheoryclass } = req.body;

    const q = `UPDATE TheoryDetails
               SET SubjectID = ?, HoursPerWeek = ?, MaxCreditMarks = ?, MaxMarksTheoryExam = ?, CWTheoryclass = ?
               WHERE TheoryID = ?`;

    const values = [SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksTheoryExam, CWTheoryclass, id];

    db.query(q, values, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ message: "TheoryDetail not found" });
        return res.status(200).json({ message: "TheoryDetail updated successfully" });
    });
});

// Delete a TheoryDetail by ID
router.delete("/:id", (req, res) => {
    const { id } = req.params;
    const q = "DELETE FROM TheoryDetails WHERE TheoryID = ?";

    db.query(q, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ message: "TheoryDetail not found" });
        return res.status(200).json({ message: "TheoryDetail deleted successfully" });
    });
});

export { router as TheoryDetailsRoutes };
