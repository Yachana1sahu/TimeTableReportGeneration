import express from 'express';
import db from '../db.js';

const router = express.Router();

// Get all computers
router.get('/', (req, res) => {
    const q = 'SELECT * FROM ComputerDetails';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a single computer by ID
router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM ComputerDetails WHERE ComputerID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new computer
router.post('/', (req, res) => {
    const { ComputerID, Processor, RAM, HDD, DateOfPurchase, Quantity, ItemID } = req.body;
    const q = 'INSERT INTO ComputerDetails (ComputerID, Processor, RAM, HDD, DateOfPurchase, Quantity, ItemID) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(q, [ComputerID, Processor, RAM, HDD, DateOfPurchase, Quantity, ItemID], (err, data) => {
        if (err) return res.json(err);
        return res.json('Computer added successfully');
    });
});

// Update an existing computer
router.put('/:id', (req, res) => {
    const ComputerID = req.params.id;
    const { Processor, RAM, HDD, DateOfPurchase, Quantity, ItemID } = req.body;
    const q = 'UPDATE ComputerDetails SET Processor = ?, RAM = ?, HDD = ?, DateOfPurchase = ?, Quantity = ?, ItemID = ? WHERE ComputerID = ?';
    db.query(q, [Processor, RAM, HDD, DateOfPurchase, Quantity, ItemID, ComputerID], (err, data) => {
        if (err) return res.json(err);
        return res.json('Computer updated successfully');
    });
});

// Delete a computer
router.delete('/:id', (req, res) => {
    const ComputerID = req.params.id;
    const q = 'DELETE FROM ComputerDetails WHERE ComputerID = ?';
    db.query(q, [ComputerID], (err, data) => {
        if (err) return res.json(err);
        return res.json('Computer deleted successfully');
    });
});

// Update quantity after use
router.put('/update-quantity/:id', (req, res) => {
    const ComputerID = req.params.id;
    const { quantityUsed } = req.body;

    // Get the current quantity
    const getCurrentQtyQuery = 'SELECT Quantity FROM ComputerDetails WHERE ComputerID = ?';
    db.query(getCurrentQtyQuery, [ComputerID], (err, results) => {
        if (err) return res.json(err);
        if (results.length === 0) return res.status(404).json("Computer not found");

        const currentQuantity = results[0].Quantity;
        const newQuantity = currentQuantity - quantityUsed;

        // Ensure the new quantity is not negative
        if (newQuantity < 0) return res.status(400).json("Insufficient stock");

        // Update the quantity
        const updateQtyQuery = 'UPDATE ComputerDetails SET Quantity = ? WHERE ComputerID = ?';
        db.query(updateQtyQuery, [newQuantity, ComputerID], (err, data) => {
            if (err) return res.json(err);
            return res.json('Quantity updated successfully');
        });
    });
});

export { router as ComputerDetailsRoutes };

