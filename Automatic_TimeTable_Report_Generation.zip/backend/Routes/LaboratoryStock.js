import express from 'express';
import db from '../db.js';

const router = express.Router();


router.get('/', (req, res) => {
    const q = 'SELECT * FROM LaboratoryStock';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM LaboratoryStock WHERE  LaboratoryStockID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

router.post('/', (req, res) => {
    const { LaboratoryID, ItemID, ItemType, Quantity } = req.body;
    const q = 'INSERT INTO LaboratoryStock (LaboratoryID, ItemID, ItemType, Quantity) VALUES (?, ?, ?, ?)';



    const updateStockQuery = 'UPDATE Stock SET Quantity = Quantity - ? WHERE ItemID = ?';
    db.query(updateStockQuery, [Quantity, ItemID], (err, updateData) => {
        if (err) return res.json(err);
        return res.json('LaboratoryStock added and Stock quantity updated successfully');
    });



});

router.put('/:id', (req, res) => {
    const LaboratoryStockID = req.params.id;
    const { LaboratoryID, ItemID, ItemType, Quantity } = req.body;



    const getCurrentStockQuery = 'SELECT Quantity FROM LaboratoryStock WHERE LaboratoryStockID = ?';
    db.query(getCurrentStockQuery, [LaboratoryStockID], (err, results) => {
        if (err) return res.json(err);

        const currentQuantity = results[0].Quantity;







        const q = 'UPDATE LaboratoryStock SET LaboratoryID = ?, ItemID = ?, ItemType = ?, Quantity = ? WHERE  LaboratoryStockID = ?';
        db.query(q, [LaboratoryID, ItemID, ItemType, Quantity, LaboratoryStockID], (err, data) => {
            if (err) return res.json(err);



            //     return res.json('LaboratoryStock updated successfully');
            const quantityDifference = Quantity - currentQuantity;
            const updateStockQuery = 'UPDATE Stock SET Quantity = Quantity - ? WHERE ItemID = ?';
            db.query(updateStockQuery, [quantityDifference, ItemID], (err, updateData) => {
                if (err) return res.json(err);
                return res.json('LaboratoryStock updated and Stock quantity adjusted successfully');
            });
        });

    });
});

router.delete('/:id', (req, res) => {
    const LaboratoryStockID = req.params.id;
    const q = 'DELETE FROM LaboratoryStock WHERE  LaboratoryStockID = ?';
    db.query(q, [LaboratoryStockID], (err, data) => {
        if (err) return res.json(err);
        return res.json('LaboratoryStockID deleted successfully');
    });
});




export { router as LaboratoryStockRoutes };
