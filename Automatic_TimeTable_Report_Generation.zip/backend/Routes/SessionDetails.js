import express from "express";
import db from "../db.js";

const router = express.Router();

// GET all sessions
router.get("/", (req, res) => {
    const q = "SELECT * FROM Session";
    db.query(q, (err, data) => {
        if (err) return res.status(500).json(err);
        return res.json(data);
    });
});

// POST (create) a new session
router.post("/", (req, res) => {
    const q = "INSERT INTO Session (`SessionName`) VALUES (?)";
    const values = [req.body.SessionName];

    db.query(q, values, (err, data) => {
        if (err) return res.status(500).json(err);
        return res.json("Session has been created successfully");
    });
});

// DELETE a session by ID
router.delete("/:id", (req, res) => {
    const sessionId = req.params.id;
    const q = "DELETE FROM Session WHERE SessionID = ?";

    db.query(q, [sessionId], (err, data) => {
        if (err) return res.status(500).json(err);
        return res.json("Session has been deleted successfully");
    });
});

// PUT (update) a session by ID
router.put("/:id", (req, res) => {
    const sessionId = req.params.id;
    const q = "UPDATE Session SET SessionName = ? WHERE SessionID = ?";
    const values = [req.body.SessionName];

    db.query(q, [...values, sessionId], (err, data) => {
        if (err) return res.status(500).json(err);
        return res.json("Session has been updated successfully");
    });
});

export { router as SessionRoutes };
