
import express from "express";
import db from "../db.js";

const router = express.Router();

router.get("/", (req, res) => {
    const q = "SELECT * FROM batchdetails";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

router.post("/", (req, res) => {
    const q = "INSERT INTO batchdetails (`BatchName`) VALUES(?)";
    const values = [req.body.BatchName];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Batch details have been created successfully");
    });
});

router.delete("/:id", (req, res) => {
    const batchId = req.params.id;
    const q = 'DELETE FROM batchdetails WHERE BatchID = ?';
    db.query(q, [batchId], (err, data) => {
        if (err) return res.json(err);
        return res.json("Batch has been deleted successfully");
    });
});

router.put("/:id", (req, res) => {
    const batchId = req.params.id;
    const q = 'UPDATE batchdetails SET BatchName = ? WHERE BatchID = ?';
    const values = [req.body.BatchName];
    db.query(q, [...values, batchId], (err, data) => {
        if (err) return res.json(err);
        return res.json("Batch has been updated successfully");
    });
});

export { router as BatchRoutes };
