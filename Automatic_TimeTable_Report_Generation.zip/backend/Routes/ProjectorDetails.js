
// src/routes/ProjectorDetailsRoutes.js
import express from 'express';
import db from '../db.js';

const router = express.Router();

// Get all projectors
router.get('/', (req, res) => {
    const q = 'SELECT * FROM ProjectorDetails';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a single projector by ID
router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM ProjectorDetails WHERE ProjectorID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new projector
router.post('/', (req, res) => {
    const q = 'INSERT INTO ProjectorDetails (Brand, Resolution, Brightness, DateOfPurchase, Quantity, ItemID) VALUES (?, ?, ?, ?, ?, ?)';
    const values = [req.body.Brand, req.body.Resolution, req.body.Brightness, req.body.DateOfPurchase, req.body.Quantity, req.body.ItemID];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Projector created successfully');
    });
});

// Update an existing projector
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const q = 'UPDATE ProjectorDetails SET Brand = ?, Resolution = ?, Brightness = ?, DateOfPurchase = ?, Quantity = ?, ItemID = ? WHERE ProjectorID = ?';
    const values = [req.body.Brand, req.body.Resolution, req.body.Brightness, req.body.DateOfPurchase, req.body.Quantity, req.body.ItemID];
    db.query(q, [...values, id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Projector updated successfully');
    });
});

// Delete a projector
router.delete('/:id', (req, res) => {
    const q = 'DELETE FROM ProjectorDetails WHERE ProjectorID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Projector deleted successfully');
    });
});

// Update quantity of a projector
router.put('/updateQuantity/:id', (req, res) => {
    const { id } = req.params;
    const { newQuantity } = req.body;
    const q = 'UPDATE ProjectorDetails SET Quantity = ? WHERE ProjectorID = ?';
    db.query(q, [newQuantity, id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Quantity updated successfully');
    });
});






export { router as ProjectorRoutes }