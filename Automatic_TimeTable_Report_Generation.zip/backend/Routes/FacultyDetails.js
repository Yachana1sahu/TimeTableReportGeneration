
import express from 'express';
import db from '../db.js';
const router = express.Router();

// Generate FullName and ShortName
const generateNameDetails = (FirstName, MiddleName, LastName) => {
    const FullName = [FirstName, MiddleName, LastName].filter(name => name).join(' ');

    // Generate ShortName with uppercase letters
    let shortName = FirstName[0].toUpperCase();
    if (MiddleName) shortName += MiddleName[0].toUpperCase();
    shortName += LastName[0].toUpperCase();

    return { FullName, ShortName: shortName };
};

// Get all faculty members
router.get('/', (req, res) => {
    const q = 'SELECT FacultyID, FirstName, MiddleName, LastName, CONCAT(FirstName, " ", MiddleName, " ", LastName) AS FullName, CONCAT(UPPER(SUBSTRING(FirstName, 1, 1)), IF(MiddleName != "", UPPER(SUBSTRING(MiddleName, 1, 1)), ""), UPPER(SUBSTRING(LastName, 1, 1))) AS ShortName FROM FacultyDetails';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a specific faculty member
router.get('/:id', (req, res) => {
    const q = 'SELECT FacultyID, FirstName, MiddleName, LastName, CONCAT(FirstName, " ", MiddleName, " ", LastName) AS FullName, CONCAT(UPPER(SUBSTRING(FirstName, 1, 1)), IF(MiddleName != "", UPPER(SUBSTRING(MiddleName, 1, 1)), ""), UPPER(SUBSTRING(LastName, 1, 1))) AS ShortName FROM FacultyDetails WHERE FacultyID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new faculty member
router.post('/', (req, res) => {
    const { FirstName, MiddleName, LastName } = req.body;

    if (!FirstName || !LastName) {
        return res.status(400).json({ message: 'FirstName and LastName are required.' });
    }

    // Generate FullName and ShortName
    const { FullName, ShortName } = generateNameDetails(FirstName, MiddleName, LastName);

    const q = 'INSERT INTO FacultyDetails (FirstName, MiddleName, LastName, FullName, ShortName) VALUES (?, ?, ?, ?, ?)';
    const values = [FirstName, MiddleName, LastName, FullName, ShortName];

    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Faculty member added successfully');
    });
});

// Update a faculty member
router.put('/:id', (req, res) => {
    const { FirstName, MiddleName, LastName } = req.body;
    const { FullName, ShortName } = generateNameDetails(FirstName, MiddleName, LastName);

    const q = 'UPDATE FacultyDetails SET FirstName = ?, MiddleName = ?, LastName = ?, FullName = ?, ShortName = ? WHERE FacultyID = ?';
    const values = [FirstName, MiddleName, LastName, FullName, ShortName, req.params.id];

    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Faculty member updated successfully');
    });
});

// Delete a faculty member
router.delete('/:id', (req, res) => {
    const q = 'DELETE FROM FacultyDetails WHERE FacultyID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Faculty member deleted successfully');
    });
});

export { router as FacultyRoutes };


