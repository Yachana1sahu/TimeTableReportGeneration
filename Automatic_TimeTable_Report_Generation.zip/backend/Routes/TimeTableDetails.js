
import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all timetables
router.get("/", (req, res) => {
    const q = "SELECT * FROM Timetable";
    db.query(q, (err, data) => {
        if (err) {
            console.error("Error fetching timetables:", err);
            return res.status(500).json({ error: "Failed to fetch timetables" });
        }
        return res.json(data);
    });
});

// Get a timetable by ID
router.get("/:id", (req, res) => {
    const timetableId = req.params.id;
    const q = "SELECT * FROM Timetable WHERE TimetableID = ?";
    db.query(q, [timetableId], (err, data) => {
        if (err) {
            console.error("Error fetching timetable by ID:", err);
            return res.status(500).json({ error: "Failed to fetch timetable" });
        }
        if (data.length === 0) {
            return res.status(404).json({ message: "Timetable not found" });
        }
        return res.json(data[0]);
    });
});

router.post("/", (req, res) => {
    const q = `
        INSERT INTO Timetable (YearSemesterID, DayOfWeekID, TimeSlotID, FacultyID, LabAssistantID, PGStudentID, SubjectID, ClassroomID, LaboratoryID, SectionID, BatchID, SessionID) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
        req.body.YearSemesterID,
        req.body.DayOfWeekID,
        req.body.TimeSlotID,
        req.body.FacultyID,
        req.body.LabAssistantID,
        req.body.PGStudentID,
        req.body.SubjectID,
        req.body.ClassroomID,
        req.body.LaboratoryID,
        req.body.SectionID,
        req.body.BatchID,
        req.body.SessionID
    ];

    db.query(q, values, (err, data) => {
        if (err) {
            console.error("Error creating timetable:", err);
            return res.status(500).json({ error: "Failed to create timetable" });
        }
        return res.json({ message: "Timetable has been created successfully" });
    });
});

// Update a timetable by ID
router.put("/:id", (req, res) => {
    const timetableId = req.params.id;
    const q = `
        UPDATE Timetable 
        SET YearSemesterID = ?, DayOfWeekID = ?, TimeSlotID = ?, FacultyID = ?, LabAssistantID = ?, PGStudentID = ?, SubjectID = ?, ClassroomID = ?, LaboratoryID = ?, SectionID = ?, BatchID = ?, SessionID = ?
        WHERE TimetableID = ?
    `;
    const values = [
        req.body.YearSemesterID,
        req.body.DayOfWeekID,
        req.body.TimeSlotID,
        req.body.FacultyID,
        req.body.LabAssistantID,
        req.body.PGStudentID,
        req.body.SubjectID,
        req.body.ClassroomID,
        req.body.LaboratoryID,
        req.body.SectionID,
        req.body.BatchID,
        req.body.SessionID
    ];

    db.query(q, [...values, timetableId], (err, data) => {
        if (err) {
            console.error("Error updating timetable:", err);
            return res.status(500).json({ error: "Failed to update timetable" });
        }
        return res.json({ message: "Timetable has been updated successfully" });
    });
});
// Delete a timetable by ID
router.delete("/:id", (req, res) => {
    const timetableId = req.params.id;
    const q = "DELETE FROM Timetable WHERE TimetableID = ?";
    db.query(q, [timetableId], (err, data) => {
        if (err) {
            console.error("Error deleting timetable:", err);
            return res.status(500).json({ error: "Failed to delete timetable" });
        }
        return res.json({ message: "Timetable has been deleted successfully" });
    });
});

export { router as TimetableRoutes };
