
import express from "express";
import db from "../db.js";

const router = express.Router();

router.get("/", (req, res) => {
    const q = "SELECT * FROM Course";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

router.post("/", (req, res) => {
    const q = "INSERT INTO Course (`CourseName`) VALUES(?)";
    const values = [req.body.CourseName];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json(" Course have been created successfully");
    });
});


// router.delete("/:id", (req, res) => {
//     const batchId = req.params.id;
//     const q = 'DELETE FROM Course WHERE CourseID = ?';
//     db.query(q, [batchId], (err, data) => {
//         if (err) return res.json(err);
//         return res.json("Course has been deleted successfully");
//     });
// });




export { router as CourseRoutes };
