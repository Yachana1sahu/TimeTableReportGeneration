import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all time slots
router.get("/", (req, res) => {
    const q = "SELECT * FROM TimeSlot";
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Create a new time slot
router.post("/", (req, res) => {
    const { TimeSlotID, StartTime, EndTime } = req.body;
    const q = "INSERT INTO TimeSlot (`StartTime`, `EndTime`) VALUES ( ?, ?)";
    const values = [StartTime, EndTime];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("TimeSlot has been created successfully");
    });
});

// Update an existing time slot
router.put("/:id", (req, res) => {
    const timeSlotId = req.params.id;
    const { StartTime, EndTime } = req.body;
    const q = "UPDATE TimeSlot SET StartTime = ?, EndTime = ? WHERE TimeSlotID = ?";
    const values = [StartTime, EndTime, timeSlotId];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("TimeSlot has been updated successfully");
    });
});

// Delete a time slot
router.delete("/:id", (req, res) => {
    const timeSlotId = req.params.id;
    const q = "DELETE FROM TimeSlot WHERE TimeSlotID = ?";
    db.query(q, [timeSlotId], (err, data) => {
        if (err) return res.json(err);
        return res.json("TimeSlot has been deleted successfully");
    });
});

export { router as TimeSlotRoutes };
