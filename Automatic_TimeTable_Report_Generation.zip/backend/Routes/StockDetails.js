import express from 'express';
import db from '../db.js';

const router = express.Router();

// Get all stock items
router.get('/', (req, res) => {
    const q = 'SELECT * FROM Stock';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a single stock item by ID
router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM Stock WHERE ItemID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new stock item
router.post('/', (req, res) => {
    const q = 'INSERT INTO Stock (ItemType, Quantity) VALUES (?, ?)';
    const values = [req.body.ItemType, req.body.Quantity];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Stock item created successfully');
    });
});

// // Update an existing stock item
// router.put('/:id', (req, res) => {
//     const ItemID = req.params.id;
//     const q = 'UPDATE Stock SET ItemType = ?, Quantity = ? WHERE ItemID = ?';
//     const values = [req.body.ItemType, req.body.Quantity];
//     db.query(q, [...values, ItemID], (err, data) => {
//         if (err) return res.json(err);
//         return res.json('Stock item updated successfully');
//     });
// });

// Update an existing stock item
router.put('/:id', (req, res) => {
    const ItemID = req.params.id;
    const { ItemType, Quantity } = req.body;

    // Get the current stock quantity
    const getCurrentStockQuery = 'SELECT Quantity FROM Stock WHERE ItemID = ?';
    db.query(getCurrentStockQuery, [ItemID], (err, results) => {
        if (err) return res.json(err);
        if (results.length === 0) return res.status(404).json("Item not found");

        const currentQuantity = results[0].Quantity;
        const newQuantity = Quantity; // For simplicity, assume you're directly setting the new quantity

        // Update the stock quantity
        const updateStockQuery = 'UPDATE Stock SET Quantity = ? WHERE ItemID = ?';
        db.query(updateStockQuery, [newQuantity, ItemID], (err, data) => {
            if (err) return res.json(err);
            return res.json('Stock item updated successfully');
        });
    });
});


// Delete a stock item
router.delete('/:id', (req, res) => {
    const ItemID = req.params.id;
    const q = 'DELETE FROM Stock WHERE ItemID = ?';
    db.query(q, [ItemID], (err, data) => {
        if (err) return res.json(err);
        return res.json('Stock item deleted successfully');
    });
});

export { router as StockRoutes };
