import express from 'express';
import db from '../db.js';

const router = express.Router();

router.get('/', (req, res) => {
    const query = 'SELECT * FROM DayOfWeek';
    db.query(query, (err, data) => {
        if (err) return res.status(500).json(err);
        res.json(data);
    });
});

export { router as DayOfWeekRoutes }