import express from 'express';
import db from '../db.js';

const router = express.Router();

// Get all ClassroomStock entries
router.get('/', (req, res) => {
    const q = 'SELECT * FROM ClassroomStock';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a specific ClassroomStock entry
router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM ClassroomStock WHERE ClassroomStockID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new ClassroomStock entry
router.post('/', (req, res) => {
    const { ClassroomID, ItemID, ItemType, Quantity } = req.body;
    const q = 'INSERT INTO ClassroomStock (ClassroomID, ItemID, ItemType, Quantity) VALUES (?, ?, ?, ?)';

    db.query(q, [ClassroomID, ItemID, ItemType, Quantity], (err, data) => {
        if (err) return res.json(err);
        const updateStockQuery = 'UPDATE Stock SET Quantity = Quantity - ? WHERE ItemID = ?';
        db.query(updateStockQuery, [Quantity, ItemID], (err, updateData) => {
            if (err) return res.json(err);
            return res.json('ClassroomStock added and Stock quantity updated successfully');
        });

    });
});

// Update a ClassroomStock entry
router.put('/:id', (req, res) => {
    const ClassroomStockID = req.params.id;
    const { ClassroomID, ItemID, ItemType, Quantity } = req.body;


    const getCurrentStockQuery = 'SELECT Quantity FROM ClassroomStock WHERE ClassroomStockID = ?';
    db.query(getCurrentStockQuery, [ClassroomStockID], (err, results) => {
        if (err) return res.json(err);

        const currentQuantity = results[0].Quantity;







        const q = 'UPDATE ClassroomStock SET ClassroomID = ?, ItemID = ?, ItemType = ?, Quantity = ? WHERE ClassroomStockID = ?';
        db.query(q, [ClassroomID, ItemID, ItemType, Quantity, ClassroomStockID], (err, data) => {
            if (err) return res.json(err);


            const quantityDifference = Quantity - currentQuantity;
            const updateStockQuery = 'UPDATE Stock SET Quantity = Quantity - ? WHERE ItemID = ?';
            db.query(updateStockQuery, [quantityDifference, ItemID], (err, updateData) => {
                if (err) return res.json(err);
                return res.json('ClassroomStock updated and Stock quantity adjusted successfully');
            });
        });

        // return res.json('ClassroomStock updated successfully');
    });
});

// Delete a ClassroomStock entry
router.delete('/:id', (req, res) => {
    const ClassroomStockID = req.params.id;
    const q = 'DELETE FROM ClassroomStock WHERE ClassroomStockID = ?';
    db.query(q, [ClassroomStockID], (err, data) => {
        if (err) return res.json(err);
        return res.json('ClassroomStock deleted successfully');
    });
});

export { router as ClassroomStockRoutes };
