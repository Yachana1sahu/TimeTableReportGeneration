// src/routes/DigitalBoardRoutes.js
import express from 'express';
import db from '../db.js';

const router = express.Router();

// Get all digital boards
router.get('/', (req, res) => {
    const q = 'SELECT * FROM DigitalBoard';
    db.query(q, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get a single digital board by ID
router.get('/:id', (req, res) => {
    const q = 'SELECT * FROM DigitalBoard WHERE DigitalBoardID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new digital board
router.post('/', (req, res) => {
    const q = 'INSERT INTO DigitalBoard (Brand, DateOfPurchase, Quantity, ItemID) VALUES (?, ?, ?, ?)';
    const values = [req.body.Brand, req.body.DateOfPurchase, req.body.Quantity, req.body.ItemID];
    db.query(q, values, (err, data) => {
        if (err) return res.json(err);
        return res.json('Digital board created successfully');
    });
});

// Update an existing digital board
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const q = 'UPDATE DigitalBoard SET Brand = ?, DateOfPurchase = ?, Quantity = ?, ItemID = ? WHERE DigitalBoardID = ?';
    const values = [req.body.Brand, req.body.DateOfPurchase, req.body.Quantity, req.body.ItemID];
    db.query(q, [...values, id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Digital board updated successfully');
    });
});

// Delete a digital board
router.delete('/:id', (req, res) => {
    const q = 'DELETE FROM DigitalBoard WHERE DigitalBoardID = ?';
    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Digital board deleted successfully');
    });
});

// Update quantity of a digital board
router.put('/updateQuantity/:id', (req, res) => {
    const { id } = req.params;
    const { newQuantity } = req.body;
    const q = 'UPDATE DigitalBoard SET Quantity = ? WHERE DigitalBoardID = ?';
    db.query(q, [newQuantity, id], (err, data) => {
        if (err) return res.json(err);
        return res.json('Quantity updated successfully');
    });
});


export { router as DigitalBoardRoutes }


