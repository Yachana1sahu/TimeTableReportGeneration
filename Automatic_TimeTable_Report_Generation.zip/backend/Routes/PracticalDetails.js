import express from "express";
import db from "../db.js";

const router = express.Router();

// Get all practical details
router.get("/", (req, res) => {
    const query = `
        SELECT p.PracticalID, p.SubjectID, s.SubjectCode, p.HoursPerWeek, p.MaxCreditMarks, p.MaxMarksPracticalExam, p.SWPractical
        FROM PracticalDetails p
        JOIN SubjectDetails s ON p.SubjectID = s.SubjectID;
    `;
    db.query(query, (err, data) => {
        if (err) return res.json(err);
        return res.json(data);
    });
});

// Get practical details by ID
router.get('/:id', (req, res) => {
    const query = 'SELECT * FROM PracticalDetails WHERE PracticalID = ?';
    db.query(query, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json(data[0]);
    });
});

// Create a new practical detail
router.post("/", (req, res) => {
    const query = `
        INSERT INTO PracticalDetails (SubjectID, HoursPerWeek, MaxCreditMarks, MaxMarksPracticalExam, SWPractical)
        VALUES (?, ?, ?, ?, ?)
    `;
    const values = [
        req.body.SubjectID,
        req.body.HoursPerWeek,
        req.body.MaxCreditMarks,
        req.body.MaxMarksPracticalExam,
        req.body.SWPractical,
    ];
    db.query(query, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Practical detail created successfully");
    });
});

// Update a practical detail by ID
router.put("/:id", (req, res) => {
    const query = `
        UPDATE PracticalDetails
        SET SubjectID = ?, HoursPerWeek = ?, MaxCreditMarks = ?, MaxMarksPracticalExam = ?, SWPractical = ?
        WHERE PracticalID = ?
    `;
    const values = [
        req.body.SubjectID,
        req.body.HoursPerWeek,
        req.body.MaxCreditMarks,
        req.body.MaxMarksPracticalExam,
        req.body.SWPractical,
        req.params.id,
    ];
    db.query(query, values, (err, data) => {
        if (err) return res.json(err);
        return res.json("Practical detail updated successfully");
    });
});

// Delete a practical detail by ID
router.delete("/:id", (req, res) => {
    const query = 'DELETE FROM PracticalDetails WHERE PracticalID = ?';
    db.query(query, [req.params.id], (err, data) => {
        if (err) return res.json(err);
        return res.json("Practical detail deleted successfully");
    });
});

export { router as PracticalRoutes };


