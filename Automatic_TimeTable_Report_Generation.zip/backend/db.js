import mysql from "mysql";

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    port: 3308,
    password: "Yachana12@",
    database: "project",
    timezone: "+00:00"
});

db.connect((err) => {
    if (err) { console.log(" connection err ") }
    else {
        console.log("Database connected!")
    }
});

export default db;