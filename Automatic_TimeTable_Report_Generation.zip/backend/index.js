import express from "express";
import cors from "cors";


import { BatchRoutes } from "./Routes/BatchDetails.js";
import { ClassRoutes } from "./Routes/ClassroomDetails.js";
import { LabRoutes } from "./Routes/LabDetails.js";
import { FacultyRoutes } from './Routes/FacultyDetails.js';
import { Lab_AssistantRoutes } from "./Routes/LabAssistDetails.js";
import { PG_StudentRoutes } from "./Routes/PgStudentDetails.js";
import { DayOfWeekRoutes } from "./Routes/DayOfWeek.js";
import { StockRoutes } from "./Routes/StockDetails.js";
import { ComputerDetailsRoutes } from "./Routes/ComputerDetails.js";
import { DigitalBoardRoutes } from "./Routes/DigitalBoradDetails.js";
import { ProjectorRoutes } from "./Routes/ProjectorDetails.js";
import { CourseRoutes } from "./Routes/CourseDetails.js";
import { YearSemRoutes } from "./Routes/YearSem.js";
import { SubjectRoutes } from "./Routes/SubjectDetails.js";
import { TheoryDetailsRoutes } from "./Routes/TheoryDetails.js";
import { PracticalRoutes } from "./Routes/PracticalDetails.js";
import { TutorialRoutes } from "./Routes/Tutorial.js";
import { LaboratoryStockRoutes } from "./Routes/LaboratoryStock.js";
import { ClassroomStockRoutes } from "./Routes/ClassroomStock.js";
import { TimeSlotRoutes } from "./Routes/TimeSlot.js";
import { TimetableRoutes } from "./Routes/TimeTableDetails.js";
import { SectionRoutes } from "./Routes/Section.js";
import { SessionRoutes } from "./Routes/SessionDetails.js";
import { TimetablesetRoutes } from "./Routes/Timetableset.js";


const app = express();
app.use(express.json());
app.use(cors());


app.use("/batchdetails", BatchRoutes);
app.use("/classroom", ClassRoutes);
app.use("/Laboratory", LabRoutes)
app.use('/faculty', FacultyRoutes);
app.use('/lab-assistant', Lab_AssistantRoutes)
app.use('/pg-student', PG_StudentRoutes)
app.use('/day-of-week', DayOfWeekRoutes)
app.use('/Stock', StockRoutes)
app.use('/ComputerDetails', ComputerDetailsRoutes)
app.use('/DigitalBoard', DigitalBoardRoutes)
app.use('/ProjectorDetails', ProjectorRoutes)
app.use('/ProjectorDetails', ProjectorRoutes)
app.use('/Course', CourseRoutes)
app.use('/YearSemester', YearSemRoutes)
app.use('/SubjectDetails', SubjectRoutes)
app.use('/TheoryDetails', TheoryDetailsRoutes)
app.use('/PracticalDetails', PracticalRoutes)
app.use("/TutorialDetails", TutorialRoutes)
app.use("/LaboratoryStock", LaboratoryStockRoutes)
app.use("/ClassroomStock", ClassroomStockRoutes)
app.use("/TimeSlot", TimeSlotRoutes)
app.use('/Timetable', TimetableRoutes)
app.use('/Section', SectionRoutes)
app.use("/Session", SessionRoutes)
app.use("/timetablesets", TimetablesetRoutes)




app.listen(8800, () => {
    console.log("connected to backend ");
});